#!/usr/bin/env bash
nohup python run_item_master.py > run_item_master.py.log 2>&1 &