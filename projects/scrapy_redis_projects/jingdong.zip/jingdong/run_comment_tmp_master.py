#!/usr/bin/env python
# -*- coding: utf-8 -*-
from jingdong.spiders.jd_comment import run_tmp_master
if __name__ == '__main__':
    run_tmp_master()

