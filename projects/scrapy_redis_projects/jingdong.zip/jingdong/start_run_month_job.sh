#!/usr/bin/env bash
#step1: 更新brand, jd_brand.py
#step2: 更新skuid, jd_skuids2.py
#step3: 更新comment, jd_comment.py
#step4: 更新cate_id, jd_item.py
#step5: 更新缺失的price， jd_price_miss.py
#step6: 生成最终结果, summary.py