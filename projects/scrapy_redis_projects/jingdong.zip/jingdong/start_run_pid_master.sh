#!/usr/bin/env bash
nohup python run_pid_master.py > run_pid_master.py.log 2>&1 &