#!/usr/bin/env bash
nohup python run_skuid_master.py > run_skuid_master.py.log 2>&1 &