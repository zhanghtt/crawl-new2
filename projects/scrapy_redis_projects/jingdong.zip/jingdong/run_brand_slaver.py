#!/usr/bin/env python
# -*- coding: utf-8 -*-
from jingdong.spiders.jd_brand import run_slaver
if __name__ == '__main__':
    run_slaver(spider_num=40)
