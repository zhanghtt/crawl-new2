#!/usr/bin/env bash
nohup python run_comment_master.py > run_comment_master.py.log 2>&1 &