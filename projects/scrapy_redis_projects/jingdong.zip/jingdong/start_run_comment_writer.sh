#!/usr/bin/env bash
nohup python run_comment_writer.py > run_comment_writer.py.log 2>&1 &